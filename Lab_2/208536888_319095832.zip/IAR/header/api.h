#ifndef _api_H_
#define _api_H_

#include  "../header/halGPIO.h"     // private library - HAL layer


extern void CountUp(void);
extern void freqMeas(void);
extern void tone_generator(void);

#endif







